# Firmware (baseado no Bruce, da pr3y)

Este projeto é o firmware **Bruce** renomeado para **"Firmware"** — apenas a marca
visível na tela foi alterada. Todo o código, a licença e os créditos originais são
mantidos.

- **Baseado em:** [pr3y/Bruce](https://github.com/pr3y/Bruce) (também espelhado em
  `BruceDevices/firmware`).
- **Licença:** AGPL-3.0-or-later. O arquivo `LICENSE` e todas as notas de copyright
  foram preservados. Este é apenas um *rebrand do nome exibido*, **não** uma
  reivindicação de autoria. O código-fonte modificado acompanha este pacote, conforme
  exige a AGPL.
- **Uso:** ferramenta de segurança ofensiva. **Use somente em redes/dispositivos
  próprios ou com autorização explícita.** Você é o único responsável pelo uso.

## Placa alvo

**LilyGO T-Display S3** (ESP32-S3, flash de 16 MB).
Ambiente do PlatformIO: `lilygo-t-display-s3`.

> Existem variantes correlatas no mesmo repositório (`lilygo-t-display-s3-touch`,
> `-mmc`, `-touch-mmc`). Este build é da versão **sem** touch e **sem** SD MMC.
> Se a sua placa tiver touch, recompile com o ambiente correspondente.

## O que foi alterado (rebrand)

- Nome exibido "Bruce" → **"Firmware"** na tela de boot, na barra de status
  (título da home), na tela de informações do dispositivo, no nome BLE anunciado
  pelo dispositivo, no SSID padrão do AP e no nome USB.
- O **logo/mascote** da tela de boot (o tubarão) foi substituído por um **gato**
  (silhueta original de um gato sentado, mesmas dimensões e formato XBM).
- Créditos "Based on Bruce by pr3y" adicionados na tela de informações.
- Identificadores internos, caminhos em SD (`/Bruce...`), nomes de ferramentas de
  ataque e atribuições no código-fonte foram **mantidos** para não quebrar nada.

## Como gravar (flash)

### Opção A — Web flasher (mais fácil), grava em 0x0

1. Conecte a T-Display S3 no USB.
2. Abra o **esptool-js**: https://espressif.github.io/esptool-js/
3. Clique em **Connect** e selecione a porta serial da placa.
4. Em **Flash Address**, use `0x0` e selecione o arquivo
   `dist/firmware-t-display-s3.bin`.
5. Clique em **Program** e aguarde. Ao final, reinicie a placa.

> `dist/firmware-t-display-s3.bin` é a imagem combinada (bootloader + tabela de
> partições + boot_app0 + aplicação) já pronta para gravar em **0x0**.
> Se a placa não entrar em modo de gravação sozinha, segure **BOOT**, toque em
> **RST** e solte **BOOT**, depois tente conectar novamente.

### Opção B — PlatformIO (a partir do código)

```bash
# instalar o PlatformIO, se necessário
pip install --user platformio

# compilar
pio run -e lilygo-t-display-s3

# compilar e gravar na placa conectada
pio run -e lilygo-t-display-s3 -t upload
```

Os offsets individuais (caso queira gravar separado) são:

| Offset   | Arquivo           |
|----------|-------------------|
| 0x0      | bootloader.bin    |
| 0x8000   | partitions.bin    |
| 0xe000   | boot_app0.bin     |
| 0x10000  | firmware.bin      |

`dist/firmware.bin` é apenas a aplicação (offset 0x10000), útil para regravar só o
app via PlatformIO/OTA.

## Atualizações

Este firmware é **compilado a partir do código-fonte** que está neste pacote. Não há
atualização automática (OTA) configurada: para atualizar, recompile com o PlatformIO
e grave novamente. Para acompanhar melhorias do upstream, veja
https://github.com/pr3y/Bruce e reaplique o rebrand.

## Observações técnicas

- Uso de flash da aplicação: ~3,80 MB em uma partição `factory` de ~4,44 MB (~82%).
- Uso de RAM em tempo de compilação: ~40,5%.
- A dependência `fastled/FastLED` foi fixada em `3.10.3` (o piso do intervalo
  `^3.10.3` já declarado pelo próprio repositório), porque a 3.10.5 tem uma regressão
  que conflita com a macro `FP` da placa. Nenhuma outra versão foi alterada.
- Não foi possível testar em hardware real (sem placa disponível aqui). A compilação
  passou de forma limpa; verifique o comportamento na sua T-Display S3.
