#include "i18n.h"
#include <string.h>

// Estado global do idioma da interface. Comeca em ingles e e' atualizado
// quando bruceConfig e' carregado do arquivo (fromFile) ou trocado no menu.
static uint8_t s_uiLang = LANG_EN;

uint8_t getUiLang() { return s_uiLang; }

void setUiLang(uint8_t lang) { s_uiLang = (lang < LANG_COUNT) ? lang : LANG_EN; }

const char *uiLangName(uint8_t lang) {
    switch (lang) {
        case LANG_PT: return "Portugues";
        case LANG_ES: return "Espanol";
        case LANG_FR: return "Francais";
        case LANG_DE: return "Deutsch";
        default: return "English";
    }
}



// Traducoes extras (frances e alemao), indexadas pelo texto em ingles.
// Mantem as chamadas TR(en, pt, es) existentes sem precisar mudar cada uma.
struct ExtraTr { const char *en; const char *fr; const char *de; };
static const ExtraTr kExtra[] = {
    {"About", "A propos", "Info"},
    {"Advanced", "Avance", "Erweitert"},
    {"Are you sure you want\nto Factory Reset?\nAll data will be lost!", "Reinitialiser l'appareil\naux reglages d'usine?\nTout sera efface!", "Wirklich auf Werks-\neinstellungen setzen?\nAlle Daten gehen verloren!"},
    {"Audio Config", "Audio", "Audio"},
    {"Back", "Retour", "Zurueck"},
    {"Brightness", "Luminosite", "Helligkeit"},
    {"Clock", "Horloge", "Uhr"},
    {"Config", "Reglages", "Einstellungen"},
    {"Deep Sleep", "Veille profonde", "Tiefschlaf"},
    {"Dev Mode", "Mode Dev", "Dev-Modus"},
    {"Dim Time", "Attenuation", "Dimmzeit"},
    {"Display & UI", "Ecran et UI", "Anzeige & UI"},
    {"Hide/Show Apps", "Afficher/Masquer", "Apps ein/aus"},
    {"Install App Store", "Installer App Store", "App Store install."},
    {"Keyboard: ", "Clavier: ", "Tastatur: "},
    {"LED Config", "Config LED", "LED-Einst."},
    {"Language", "Langue", "Sprache"},
    {"Language: ", "Langue: ", "Sprache: "},
    {"Main Menu", "Menu principal", "Hauptmenue"},
    {"No", "Non", "Nein"},
    {"Orientation", "Orientation", "Ausrichtung"},
    {"Power Off Device?", "Eteindre l'appareil?", "Geraet ausschalten?"},
    {"Power Off", "Eteindre", "Ausschalten"},
    {"Power", "Energie", "Energie"},
    {"Restart", "Redemarrer", "Neustart"},
    {"Sleep", "Veille", "Schlafen"},
    {"Sound Volume", "Volume", "Lautstaerke"},
    {"Sound: ", "Son: ", "Ton: "},
    {"Startup App", "App au demarrage", "Start-App"},
    {"System Config", "Systeme", "System"},
    {"UI Color", "Couleur UI", "UI-Farbe"},
    {"UI Theme", "Theme", "Thema"},
    {"WiFi Startup: ", "WiFi au demarrage: ", "WiFi beim Start: "},
    {"Yes", "Oui", "Ja"},
    {"Others", "Autres", "Andere"},
    {"Connect", "Connecter", "Verbinden"},
    {"Files", "Fichiers", "Dateien"},
    {"JS Interpreter", "Interpreteur JS", "JS-Interpreter"},
};

static const char *extraLookup(const char *en) {
    for (const auto &e : kExtra) {
        if (strcmp(e.en, en) == 0) return (s_uiLang == LANG_FR) ? e.fr : e.de;
    }
    return en; // sem traducao: cai pro ingles
}

const char *TR(const char *en, const char *pt, const char *es) {
    if (s_uiLang == LANG_PT) return pt;
    if (s_uiLang == LANG_ES) return es;
    if (s_uiLang == LANG_FR || s_uiLang == LANG_DE) return extraLookup(en);
    return en;
}

String menuTitleTR(const String &en) {
    // Acronimos e nomes de protocolo (WiFi, BLE, RF, RFID, IR, FM, NRF24,
    // LoRa, GPS, Ethernet) permanecem iguais de proposito.
    if (s_uiLang == LANG_PT) {
        if (en == "Others") return "Outros";
        if (en == "Clock") return "Relogio";
        if (en == "Connect") return "Conectar";
        if (en == "Files") return "Arquivos";
        if (en == "Config") return "Ajustes";
        if (en == "JS Interpreter") return "Interpretador JS";
    } else if (s_uiLang == LANG_ES) {
        if (en == "Others") return "Otros";
        if (en == "Clock") return "Reloj";
        if (en == "Connect") return "Conectar";
        if (en == "Files") return "Archivos";
        if (en == "Config") return "Ajustes";
        if (en == "JS Interpreter") return "Interprete JS";
    } else if (s_uiLang == LANG_FR || s_uiLang == LANG_DE) {
        return String(extraLookup(en.c_str()));
    }
    return en;
}

// ---- Aviso de uso responsavel (mostrado apenas no primeiro boot) --------------
// ASCII apenas: a fonte do display nao renderiza acentos.
const char *disclaimerTitle() {
    switch (s_uiLang) {
        case LANG_PT: return "Uso responsavel";
        case LANG_ES: return "Uso responsable";
        case LANG_FR: return "Usage responsable";
        case LANG_DE: return "Verantwortungsvolle Nutzung";
        default: return "Responsible use";
    }
}

const char *disclaimerBody() {
    switch (s_uiLang) {
        case LANG_PT:
            return "Somente para uso autorizado. Use apenas em redes e dispositivos "
                   "seus ou que voce tenha permissao para testar. Voce e responsavel "
                   "pelo uso desta ferramenta.";
        case LANG_ES:
            return "Solo para uso autorizado. Usalo unicamente en redes y dispositivos "
                   "propios o que tengas permiso para probar. Eres responsable del uso "
                   "de esta herramienta.";
        case LANG_FR:
            return "Reserve a un usage autorise. A utiliser uniquement sur des reseaux "
                   "et appareils qui vous appartiennent ou que vous etes autorise a "
                   "tester. Vous etes responsable de l'usage de cet outil.";
        case LANG_DE:
            return "Nur fuer autorisierte Nutzung. Nur in eigenen Netzwerken und Geraeten "
                   "oder mit ausdruecklicher Erlaubnis testen. Du bist fuer die Nutzung "
                   "dieses Tools verantwortlich.";
        default:
            return "For authorized use only. Use only on networks and devices you own or "
                   "have permission to test. You are responsible for how you use this tool.";
    }
}
