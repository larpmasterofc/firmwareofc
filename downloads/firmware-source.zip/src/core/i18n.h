#ifndef __FW_I18N_H__
#define __FW_I18N_H__

#include <Arduino.h>

// Idiomas de interface suportados pelo firmware "Firmware".
// LANG_EN = Ingles (padrao, comportamento original do Bruce)
// LANG_PT = Portugues (pt-BR)
enum UiLanguage { LANG_EN = 0, LANG_PT = 1, LANG_ES = 2, LANG_FR = 3, LANG_DE = 4, LANG_COUNT = 5 };

// Nome exibido de cada idioma no seletor (ASCII, a fonte nao tem acentos).
const char *uiLangName(uint8_t lang);

// Idioma atual (global, sincronizado a partir de bruceConfig.uiLang no boot).
uint8_t getUiLang();
void setUiLang(uint8_t lang);

// Retorna a string em portugues quando o idioma atual e' PT, senao a em ingles.
// Ponteiros const char*: use literais de string em ambos os lados.
const char *TR(const char *en, const char *pt, const char *es);

// Texto do aviso de uso responsavel, ja no idioma atual (ASCII, sem acento).
const char *disclaimerTitle();
const char *disclaimerBody();


#endif

// Traduz APENAS o rotulo exibido dos itens do menu principal (nao altera a
// identidade interna retornada por getName(), usada para comparacoes).
String menuTitleTR(const String &en);
